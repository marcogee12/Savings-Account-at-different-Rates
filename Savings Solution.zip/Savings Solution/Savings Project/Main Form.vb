﻿' Name:         Savings Project Advanced
' Purpose:      Display a savings account balance
'               for each of 5 years using rates
'               from 3% to 7% in increments of 1%.
' Programmer:   Marco Gomez on 6/23/2019

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Calculate account balances for each of five years
        ' using rates from 3% to 7% in increments of 1%.
        'Scope of Variables used in the program
        Dim dblDeposit As Double
        Dim dblBalance As Double
        Dim lstDeposits() As Double = {dblDeposit}
        Dim dblNextYrBal As New List(Of Double)

        'Gives deposit info from user intput
        Double.TryParse(txtDeposit.Text, dblDeposit)

        'Creates a list for the balances, first one on the list will be the deposit
        dblNextYrBal.Add(dblDeposit)

        'Provides a index counter for the list above
        Dim dblIndex As Int32 = 0

        txtBalance.Text = "Year" & ControlChars.Tab &
        "Rate" & ControlChars.Tab & "Balance" &
        ControlChars.NewLine

        ' Calculate and display account balances. 

        'For each year from 1 to 10, and assigns an index to start off with depending on the year.
        For y As Integer = 1 To 10
            If y = 1 Then
                dblIndex = 0
            ElseIf y = 2 Then
                dblIndex = 1
            ElseIf y = 3 Then
                dblIndex = 6
            ElseIf y = 4 Then
                dblIndex = 11
            ElseIf y = 5 Then
                dblIndex = 16
            ElseIf y = 6 Then
                dblIndex = 21
            ElseIf y = 7 Then
                dblIndex = 26
            ElseIf y = 8 Then
                dblIndex = 31
            ElseIf y = 9 Then
                dblIndex = 36
            ElseIf y = 10 Then
                dblIndex = 41
            End If
            txtBalance.AppendText(Convert.ToString(y) &
                                  ControlChars.NewLine)

            'For each percent from 3 to 7 it will calculate balance based off the balance list depedning
            'on the assigned index's actual value
            For p As Double = 3 To 7
                dblBalance = (dblNextYrBal.Item(dblIndex) / 100 * p) + dblNextYrBal.Item(dblIndex)
                txtBalance.AppendText(ControlChars.Tab &
                                      (p) & "%" &
                                      ControlChars.Tab &
                                      Convert.ToString(Math.Round(dblBalance, 2)) &
                                      ControlChars.NewLine)

                'Add the calculated balance to the balance list
                dblNextYrBal.Add(dblBalance)

                'If the year the program is iterating through is greater than 1 it will increment
                'the index counter by 1 so that it takes the value of the next item in the list.
                If y > 1 Then
                    dblIndex += 1
                End If
            Next
        Next
    End Sub

    Private Sub txtDeposit_Enter(sender As Object, e As EventArgs) Handles txtDeposit.Enter
        txtDeposit.SelectAll()
    End Sub

    Private Sub txtDeposit_TextChanged(sender As Object, e As EventArgs) Handles txtDeposit.TextChanged
        txtBalance.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtDeposit_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDeposit.KeyPress
        ' Allows the text box to accept only numbers, the period, and the Backspace key.

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> "." AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub
End Class
